#include "add_minus.h"

int add(int a, int b)
{
	return a+b;
}

int minus(int a, int b)
{
	return a-b;
}
