#include <stdio.h>
#include "foo1.h"
#include "foo2.h"

int main(void)
{
	foo1();
	foo2();
	return 0;
}
