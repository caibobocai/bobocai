#ifndef __FOO2_H__
#define __FOO2_H__

void foo2(void);

#endif
