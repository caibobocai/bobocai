#include <stdio.h>
#include "foo2.h"

void foo2(void)
{
	printf("Hello foo2!\n");
}
