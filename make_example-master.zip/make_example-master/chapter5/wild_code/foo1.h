#ifndef __FOO1_H__
#define __FOO1_H__

void foo1(void);

#endif
